To execute query
chmod +x scriptname
./scriptname


